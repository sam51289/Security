
insert into `course` values ('hadoop','Hadoop Developer Course for CloudEra Certification',24,'hadoop','Hadoop',0,0,6000,'100',5),('soap','SOAP Web Services course in Depth',40,'SOAPWebServices','SOAP Web Services',0,0,2500,'50',5),
('hibernate','Hibernate and JPA in Depth',11,'hibernate','Hibernate and JPA in Depth',0,0,2500,'50',5);