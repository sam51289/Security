package com.way2learnonline.dao;

import com.way2learnonline.entity.AboutUs;

public interface AboutUsDao {

	AboutUs get(String primaryKey);

}
