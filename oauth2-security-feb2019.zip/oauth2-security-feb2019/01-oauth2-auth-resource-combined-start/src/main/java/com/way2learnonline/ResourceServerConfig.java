package com.way2learnonline;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

@Configuration

// TODO-7 Configure  annotation to enablr Resource Server
//@EnableResourceServer

// TODO -8 Configure Annotation to enable global method security and enable prepost annotations
//@EnableGlobalMethodSecurity(prePostEnabled=true)
public class ResourceServerConfig {

}
